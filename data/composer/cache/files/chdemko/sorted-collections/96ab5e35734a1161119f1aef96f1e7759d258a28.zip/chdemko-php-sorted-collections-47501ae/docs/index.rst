Welcome to PHP Sorted Collections documentation!
================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents

   Installation <README>
   Usage <usage>
   Application Programming Interface <api>

Indices and tables
==================

* :ref:`genindex`

