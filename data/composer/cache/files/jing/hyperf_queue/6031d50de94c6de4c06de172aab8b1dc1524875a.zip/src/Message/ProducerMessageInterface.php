<?php

declare(strict_types=1);

namespace Jing\Queue\Message;

interface ProducerMessageInterface extends MessageInterface
{
    public function setPayload($data);

    public function payload(): string;
}
