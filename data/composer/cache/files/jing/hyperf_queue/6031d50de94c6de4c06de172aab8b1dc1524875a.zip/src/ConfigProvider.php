<?php

declare(strict_types=1);

namespace Jing\Queue;

use Jing\Queue\Listener\BeforeMainServerStartListener;
use Jing\Queue\Listener\MainWorkerStartListener;
use Jing\Queue\Packer\Packer;
use Hyperf\Utils\Packer\JsonPacker;
use GuzzleHttp\Client;

class ConfigProvider
{
    public function __invoke(): array
    {
        return [
            'dependencies' => [
                Packer::class => JsonPacker::class,
            ],
            'listeners' => [
                BeforeMainServerStartListener::class => 99,
                MainWorkerStartListener::class,
            ],
            'annotations' => [
                'scan' => [
                    'paths' => [
                        __DIR__,
                    ],
                    'class_map' => [
                        Client::class => __DIR__ . '/class_map/GuzzleHttp/Client.php',
                    ],
                ],
            ],
            'publish' => [
                [
                    'id' => 'config',
                    'description' => 'The config for queue.',
                    'source' => __DIR__ . '/../publish/queue.php',
                    'destination' => BASE_PATH . '/config/autoload/queue.php',
                ],
            ],
        ];
    }
}
