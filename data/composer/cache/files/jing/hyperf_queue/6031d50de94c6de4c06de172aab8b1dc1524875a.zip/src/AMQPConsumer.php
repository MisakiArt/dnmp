<?php

declare(strict_types=1);

namespace Jing\Queue;

use Jing\Queue\Exception\MessageException;
use Jing\Queue\Builder\AMQPQueueBuilder;
use Jing\Queue\Message\ConsumerMessageInterface;
use Jing\Queue\Message\MessageInterface;
use Hyperf\ExceptionHandler\Formatter\FormatterInterface;
use Hyperf\Process\ProcessManager;
use Hyperf\Utils\Coroutine\Concurrent;
use Hyperf\Contract\StdoutLoggerInterface;
use PhpAmqpLib\Channel\AMQPChannel;
use PhpAmqpLib\Exception\AMQPTimeoutException;
use PhpAmqpLib\Message\AMQPMessage;
use Psr\Container\ContainerInterface;

use Throwable;

class AMQPConsumer extends AMQPBuilder
{
    /**
     * @var bool
     */
    protected $status = true;

    /**
     * @var StdoutLoggerInterface
     */
    private $logger;

    public function __construct(
        ContainerInterface $container,
        AMQPConnectionFactory $factory,
        StdoutLoggerInterface $logger
    ) {
        parent::__construct($container, $factory);
        $this->logger = $logger;
    }

    public function consume(ConsumerMessageInterface $consumerMessage): void
    {
        $connection = $this->factory->getConnection($consumerMessage->getDriver());
        try {
            $channel = $connection->getConfirmChannel();
            $this->declare($consumerMessage, $channel);
            $concurrent = $this->getConcurrent($consumerMessage->getDriver());
            $maxConsumption = $consumerMessage->getMaxConsumption();
            $currentConsumption = 0;
            $channel->basic_consume(
                $consumerMessage->getQueue(),
                '',
                false,
                false,
                false,
                false,
                function(AMQPMessage $message) use ($consumerMessage, $concurrent) {
                    $callback = $this->getCallback($consumerMessage, $message);
                    if (!$concurrent instanceof Concurrent) {
                        return parallel([$callback]);
                    }
                    $concurrent->create($callback);
                }
            );

            while ($channel->is_consuming() && ProcessManager::isRunning()) {
                try {
                    $channel->wait(null, false, $consumerMessage->getWaitTimeout());
                    if ($maxConsumption > 0 && ++$currentConsumption >= $maxConsumption) {
                        break;
                    }
                } catch (AMQPTimeoutException $exception) {
                    $this->logger->error((string) $exception);
                } catch (\Throwable $exception) {
                    $this->logger->error((string) $exception);
                    break;
                }
            }
        } catch (\Throwable $exception) {
            isset($channel) && $channel->close();
            throw $exception;
        }

        $this->waitConcurrentHandled($concurrent);
        $connection->releaseChannel($channel, true);
    }

    public function getQueueBuilder(string $queue): AMQPQueueBuilder
    {
        return (new AMQPQueueBuilder())->setQueue($queue);
    }

    public function declare(MessageInterface $message, ?AMQPChannel $channel = null, bool $release = false): void
    {
        if (!$message instanceof ConsumerMessageInterface) {
            throw new MessageException('Message must instanceof ' . ConsumerMessageInterface::class);
        }

        if (!$channel) {
            $connection = $this->factory->getConnection($message->getDriver());
            $channel = $connection->getChannel();
        }

        parent::declare($message, $channel);

        $queue = $message->getQueue();
        $builder = $this->getQueueBuilder($queue);
        $channel->queue_declare($builder->getQueue(), $builder->isPassive(), $builder->isDurable(), $builder->isExclusive(), $builder->isAutoDelete(), $builder->isNowait(), $builder->getArguments(), $builder->getTicket());
        $exchange = $message->getTopic();
        $tag = $exchange ? $message->getTag() : $queue;
        $routeKeys = explode(',', $tag);
        array_walk($routeKeys, 'trim');
        foreach ($routeKeys as $routeKey) {
            $channel->queue_bind($queue, $exchange, $routeKey);
        }
        $channel->basic_qos(0, 1, false);
    }

    /**
     * Wait the tasks in concurrent handled, the max wait time is 5s.
     * @param int $interval The wait interval ms
     * @param int $count The wait count
     */
    protected function waitConcurrentHandled(?Concurrent $concurrent, int $interval = 10, int $count = 500): void
    {
        $index = 0;
        while ($concurrent && ! $concurrent->isEmpty()) {
            usleep($interval * 1000);
            if ($index++ > $count) {
                break;
            }
        }
    }

    protected function getConcurrent(string $driver): ?Concurrent
    {
        $concurrent = (int) $this->container->get(DriverFactory::class)->getDriverConfigByKey($driver, 'concurrent.limit', 0);
        if ($concurrent > 1) {
            return new Concurrent($concurrent);
        }

        return null;
    }

    protected function getCallback(ConsumerMessageInterface $consumerMessage, AMQPMessage $message)
    {
        return function() use ($consumerMessage, $message) {
            $data = $consumerMessage->unserialize($message->getBody());
            try {
                $result = $consumerMessage->consumeMessage($data, $message);
            } catch (Throwable $exception) {
                if ($this->container->has(FormatterInterface::class)) {
                    $formatter = $this->container->get(FormatterInterface::class);
                    $this->logger->error($formatter->format($exception));
                } else {
                    $this->logger->error($exception->getMessage());
                }
                $result = Result::DROP;
            }

            if ($result === Result::ACK) {
                $message->ack();
            } else if ($result === Result::NACK) {
                $message->nack(true);
            } else if ($result === Result::REQUEUE) {
                $message->reject(true);
            } else {
                $message->reject();
            }
            return true;
        };
    }
}
