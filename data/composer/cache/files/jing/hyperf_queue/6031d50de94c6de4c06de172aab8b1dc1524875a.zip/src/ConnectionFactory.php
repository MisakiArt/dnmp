<?php

declare(strict_types=1);

namespace Jing\Queue;

use Hyperf\Contract\ConfigInterface;
use Psr\Container\ContainerInterface;
use InvalidArgumentException;

abstract class ConnectionFactory
{
    /**
     * @var ContainerInterface
     */
    protected $container;

    /**
     * @var ConfigInterface
     */
    protected $config;

    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
        $this->config = $this->container->get(ConfigInterface::class);
    }

    public function getRealDriver($driver): string
    {
        if ('default' === $driver) {
            $key = 'queue.default';
            if (!$this->config->has($key)) {
                throw new InvalidArgumentException(sprintf('config[%s] is not exist!', $key));
            }
            $driver = $this->config->get($key);
        }
        return $driver;
    }

    public function getConfig(string $driver): array
    {
        $driver = $this->getRealDriver($driver);
        $key = sprintf('queue.drivers.%s', $driver);
        if (!$this->config->has($key)) {
            throw new InvalidArgumentException(sprintf('config[%s] is not exist!', $key));
        }

        return $this->config->get($key);
    }
}
