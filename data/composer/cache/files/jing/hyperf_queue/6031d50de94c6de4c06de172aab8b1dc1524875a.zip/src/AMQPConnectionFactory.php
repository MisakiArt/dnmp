<?php

declare(strict_types=1);

namespace Jing\Queue;

use Jing\Queue\IO\AMQPSwooleIO;
use Hyperf\Contract\StdoutLoggerInterface;
use Hyperf\Utils\Arr;
use Hyperf\Utils\Coroutine\Locker;
use Psr\Container\ContainerInterface;

class AMQPConnectionFactory extends ConnectionFactory
{
    /**
     * @var AMQPConnection[][]
     */
    protected $connections = [];

    public function __construct(ContainerInterface $container)
    {
        parent::__construct($container);
    }

    public function refresh(string $driver)
    {
        $config = $this->getConfig($driver);
        $count = $config['pool']['connections'] ?? 1;

        if (Locker::lock(static::class)) {
            try {
                for ($i = 0; $i < $count; ++$i) {
                    $connection = $this->make($config);
                    $this->connections[$driver][] = $connection;
                }
            } finally {
                Locker::unlock(static::class);
            }
        }
    }

    public function getConnection(string $driver): AMQPConnection
    {
        $driver = $this->getRealDriver($driver);
        if (!empty($this->connections[$driver])) {
            $index = array_rand($this->connections[$driver]);
            $connection = $this->connections[$driver][$index];
            if (! $connection->isConnected()) {
                if (Locker::lock(static::class . 'getConnection')) {
                    try {
                        unset($this->connections[$driver][$index]);
                        $connection->close();
                        $connection = $this->make($this->getConfig($driver));
                        $this->connections[$driver][] = $connection;
                    } finally {
                        Locker::unlock(static::class . 'getConnection');
                    }
                } else {
                    return $this->getConnection($driver);
                }
            }

            return $connection;
        }

        $this->refresh($driver);
        return Arr::random($this->connections[$driver]);
    }

    public function make(array $config): AMQPConnection
    {
        $host = $config['host'] ?? 'localhost';
        $port = $config['port'] ?? 5672;
        $user = $config['user'] ?? 'guest';
        $password = $config['password'] ?? 'guest';
        $vhost = $config['vhost'] ?? '/';
        $openSSL = $config['open_ssl'] ?? false;

        $params = new AMQPParams(Arr::get($config, 'params', []));
        $io = new AMQPSwooleIO(
            $host,
            $port,
            $params->getConnectionTimeout(),
            $params->getReadWriteTimeout(),
            $openSSL
        );

        $connection = new AMQPConnection(
            $user,
            $password,
            $vhost,
            $params->isInsist(),
            $params->getLoginMethod(),
            $params->getLoginResponse(),
            $params->getLocale(),
            $io,
            $params->getHeartbeat(),
            $params->getConnectionTimeout(),
            $params->getChannelRpcTimeout()
        );

        return $connection->setParams($params)
            ->setLogger($this->container->get(StdoutLoggerInterface::class));
    }
}
