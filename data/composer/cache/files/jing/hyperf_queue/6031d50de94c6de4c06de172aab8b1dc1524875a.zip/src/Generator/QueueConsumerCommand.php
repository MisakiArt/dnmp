<?php

declare(strict_types=1);

namespace Jing\Queue\Generator;

use Hyperf\Command\Annotation\Command;
use Hyperf\Devtool\Generator\GeneratorCommand;

/**
 * @Command
 */
#[Command]
class QueueConsumerCommand extends GeneratorCommand
{
    public function __construct()
    {
        parent::__construct('gen:queue-consumer');
        $this->setDescription('Create a new queue consumer class');
    }

    protected function getStub(): string
    {
        return $this->getConfig()['stub'] ?? __DIR__ . '/stubs/queue-consumer.stub';
    }

    protected function getDefaultNamespace(): string
    {
        return $this->getConfig()['namespace'] ?? 'App\\Queue\\Consumer';
    }
}
