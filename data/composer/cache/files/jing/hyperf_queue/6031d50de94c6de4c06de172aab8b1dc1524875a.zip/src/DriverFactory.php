<?php

declare(strict_types=1);

namespace Jing\Queue;

use Psr\Container\ContainerInterface;

class DriverFactory extends ConnectionFactory
{

    public function __construct(ContainerInterface $container)
    {
        parent::__construct($container);
    }

    public function getDriver(string $type, string $driver = 'default')
    {
        $config = $this->getConfig($driver);
        return $this->container->get($config[$type]);
    }

    public function getDriverConfigByKey($driver, $key, $default = '')
    {
        $driver = $this->getRealDriver($driver);
        $key = sprintf('queue.drivers.%s.%s', $driver, $key);
        return $this->getConfigByKey($key, $default);
    }

    public function getConfigByKey($key, $default = '')
    {
        return $this->config->get($key, $default);
    }

    public function getPrefix(): string
    {
        return $this->getConfigByKey('queue.prefix');
    }
}
