<?php

declare(strict_types=1);

namespace Jing\Queue\Message;

use Jing\Queue\DriverFactory;
use Hyperf\Utils\ApplicationContext;

abstract class Message implements MessageInterface
{
    /**
     * @var string
     */
    protected $driver = 'default';

    /**
     * @var string
     */
    protected $topic = '';

    /**
     * @var string
     */
    protected $queue = '';

    /**
     * @var array|string
     */
    protected $tag = '';

    public function setTopic(string $topic): self
    {
        $this->topic = $topic;
        return $this;
    }

    public function getTopic(): string
    {
        return empty($this->topic) ? '' : $this->getPrefix() . $this->topic;
    }

    public function setQueue(string $queue): self
    {
        $this->queue = $queue;
        return $this;
    }

    public function getQueue(): string
    {
        return $this->getPrefix() . $this->queue;
    }

    public function setTag($tag): self
    {
        $this->tag = $tag;
        return $this;
    }

    public function getTag()
    {
        return $this->tag;
    }

    public function setDriver($driver): self
    {
        $this->driver = $driver;
        return $this;
    }

    public function getDriver(): string
    {
        return $this->driver;
    }

    public function serialize(): string
    {
        throw new MessageException('You have to overwrite serialize() method.');
    }

    public function unserialize(string $data)
    {
        throw new MessageException('You have to overwrite unserialize() method.');
    }

    private function getPrefix(): string
    {
        return ApplicationContext::getContainer()->get(DriverFactory::class)->getPrefix();
    }
}
