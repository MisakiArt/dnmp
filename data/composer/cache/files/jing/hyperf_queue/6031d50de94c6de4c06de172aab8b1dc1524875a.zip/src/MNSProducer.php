<?php

declare(strict_types=1);

namespace Jing\Queue;

use Jing\Queue\Message\ProducerMessageInterface;
use Jing\Queue\Annotation\Producer;
use Hyperf\Di\Annotation\AnnotationCollector;
use AliyunMNS\Requests\PublishMessageRequest;
use AliyunMNS\Requests\SendMessageRequest;
use AliyunMNS\Exception\MnsException;

class MNSProducer extends MNSBuilder
{
    public function produce(ProducerMessageInterface $producerMessage, bool $confirm = false, int $timeout = 5): bool
    {
        return retry(1, function () use ($producerMessage, $confirm, $timeout) {
            return $this->produceMessage($producerMessage, $confirm, $timeout);
        });
    }

    private function produceMessage(ProducerMessageInterface $producerMessage, bool $confirm = false, int $timeout = 5)
    {
        $this->injectMessageProperty($producerMessage);
        $this->connection = $this->factory->getConnection($producerMessage->getDriver());
        $data = $producerMessage->payload();
        $topicName = $producerMessage->getTopic();
        $queueName = $producerMessage->getQueue();
        $filterTag = $producerMessage->getTag();
        try {
            if ($topicName && $filterTag) {
                return $this->pushTopic($data, $topicName, $filterTag);
            } else {
                return $this->pushQueue($data, $queueName);
            }
        } catch (\Throwable $exception) {
            throw $exception;
        }
    }

    protected function pushTopic($data, $topicName, $filterTag): bool {
        $topic = $this->getTopic($topicName);
        $request = new PublishMessageRequest($data, $filterTag);
        try {
            $topic->publishMessage($request);
            return true;
        } catch (MnsException $e) {
            echo "PublishMessage Failed: " . $e->getMessage();
        }
        return false;
    }

    protected function pushQueue($data, $queueName): bool {
        $queue = $this->getQueue($queueName);
        $request = new SendMessageRequest($data);
        try {
            $queue->sendMessage($request);
            return true;
        } catch (MnsException $e) {
            echo "SendMessage Failed: " . $e->getMessage();
        }
        return false;
    }

    private function injectMessageProperty(ProducerMessageInterface $producerMessage)
    {
        if (class_exists(AnnotationCollector::class)) {
            /** @var null|\Jing\Queue\Annotation\Producer $annotation */
            $annotation = AnnotationCollector::getClassAnnotation(get_class($producerMessage), Producer::class);
            if ($annotation) {
                $annotation->driver && $producerMessage->setDriver($annotation->driver);
                $annotation->topic && $producerMessage->setTopic($annotation->topic);
                $annotation->queue && $producerMessage->setQueue($annotation->queue);
                $annotation->tag && $producerMessage->setTag($annotation->tag);
            }
        }
    }
}
