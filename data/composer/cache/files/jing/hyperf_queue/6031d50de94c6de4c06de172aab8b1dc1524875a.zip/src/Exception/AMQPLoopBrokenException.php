<?php

declare(strict_types=1);

namespace Jing\Queue\Exception;

class AMQPLoopBrokenException extends \RuntimeException
{
}
