<?php

declare(strict_types=1);

namespace Jing\Queue\Listener;

use Jing\Queue\Annotation\Producer;
use Jing\Queue\DriverFactory;
use Jing\Queue\Message\ProducerMessageInterface;
use Hyperf\Contract\StdoutLoggerInterface;
use Hyperf\Di\Annotation\AnnotationCollector;
use Hyperf\Event\Contract\ListenerInterface;
use Hyperf\Framework\Event\MainWorkerStart;
use Hyperf\Server\Event\MainCoroutineServerStart;
use Psr\Container\ContainerInterface;
use Doctrine\Instantiator\Instantiator;

class MainWorkerStartListener implements ListenerInterface
{
    /**
     * @var ContainerInterface
     */
    private $container;

    /**
     * @var StdoutLoggerInterface
     */
    private $logger;

    public function __construct(ContainerInterface $container, StdoutLoggerInterface $logger)
    {
        $this->container = $container;
        $this->logger = $logger;
    }

    /**
     * @return string[] returns the events that you want to listen
     */
    public function listen(): array
    {
        return [
            MainWorkerStart::class,
            MainCoroutineServerStart::class,
        ];
    }

    /**
     * Handle the Event when the event is triggered, all listeners will
     * complete before the event is returned to the EventDispatcher.
     */
    public function process(object $event)
    {
        // Declare exchange and routingKey
        $producerMessages = AnnotationCollector::getClassesByAnnotation(Producer::class);
        if ($producerMessages) {
            $instantiator = $this->container->get(Instantiator::class);
            $driver = $this->container->get(DriverFactory::class);
            /**
             * @var string $producerMessageClass
             * @var Producer $annotation
             */
            foreach ($producerMessages as $producerMessageClass => $annotation) {
                $producer = $driver->getDriver('producer', $annotation->driver);
                $instance = $instantiator->instantiate($producerMessageClass);
                if (! $instance instanceof ProducerMessageInterface) {
                    continue;
                }
                $annotation->driver && $instance->setDriver($annotation->driver);
                $annotation->topic && $instance->setTopic($annotation->topic);
                $annotation->queue && $instance->setQueue($annotation->queue);
                $annotation->tag && $instance->setTag($annotation->tag);
                try {
                    $producer->declare($instance);
                } catch (\Throwable $exception) {
                    $this->logger->error((string) $exception);
                }
            }
        }
    }
}
