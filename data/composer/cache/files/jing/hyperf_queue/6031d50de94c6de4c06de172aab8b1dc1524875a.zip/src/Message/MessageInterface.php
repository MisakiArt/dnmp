<?php

declare(strict_types=1);

namespace Jing\Queue\Message;

interface MessageInterface
{
    public function setDriver(string $driver);

    public function getDriver(): string;

    public function setTopic(string $topic);

    public function getTopic(): string;

    public function setQueue(string $queue);

    public function getQueue(): string;

    public function setTag($tag);

    public function getTag();

    public function serialize(): string;

    public function unserialize(string $data);
}
