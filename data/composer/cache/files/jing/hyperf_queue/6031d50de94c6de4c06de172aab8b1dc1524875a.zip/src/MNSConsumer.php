<?php

declare(strict_types=1);

namespace Jing\Queue;

use Jing\Queue\Message\ConsumerMessageInterface;
use Jing\Queue\Message\MessageInterface;
use AliyunMNS\Exception\MnsException;
use AliyunMNS\Model\SubscriptionAttributes;
use Hyperf\ExceptionHandler\Formatter\FormatterInterface;
use Hyperf\Utils\Coroutine\Concurrent;
use Hyperf\Contract\StdoutLoggerInterface;
use Psr\Container\ContainerInterface;
use Hyperf\Process\ProcessManager;

class MNSConsumer extends MNSBuilder
{
    /**
     * @var bool
     */
    protected $status = true;

    /**
     * @var StdoutLoggerInterface
     */
    private $logger;

    public function __construct(
        ContainerInterface $container,
        MNSConnectionFactory $factory,
        StdoutLoggerInterface $logger
    ) {
        parent::__construct($container, $factory);
        $this->logger = $logger;
    }

    public function consume(ConsumerMessageInterface $consumerMessage): void
    {
        try {
            $concurrent = $this->getConcurrent($consumerMessage->getDriver());
            $this->declare($consumerMessage);
            $normalQueue = empty($consumerMessage->getTopic());
            $queue = $this->getQueue($consumerMessage->getQueue(), $normalQueue);

            $maxConsumption = $consumerMessage->getMaxConsumption();
            $currentConsumption = 0;
            $waitTimeout = $consumerMessage->getWaitTimeout();
            $wait_seconds = $this->container->get(DriverFactory::class)->getDriverConfigByKey($consumerMessage->getDriver(), 'wait_seconds');

            while (ProcessManager::isRunning()) {
                try {
                    $message = $queue->receiveMessage($wait_seconds);
                    $callback = $this->getCallback($queue, $consumerMessage, $message);
                    if (!$concurrent instanceof Concurrent) {
                        parallel([$callback]);
                    } else {
                        $concurrent->create($callback);
                    }
                } catch (MnsException $exception) {
                    if ($maxConsumption > 0 && ++$currentConsumption >= $maxConsumption) {
                        break;
                    }
                    if ($waitTimeout > 0) {
                        usleep($waitTimeout * 1000000);
                    }
                }
            }
        } catch (\Throwable $exception) {
        }

        $this->waitConcurrentHandled($concurrent);
    }

    public function declare(MessageInterface $message, $connection = null): void
    {
        if (!$message instanceof ConsumerMessageInterface) {
            throw new MessageException('Message must instanceof ' . ConsumerMessageInterface::class);
        }
        if (!$connection) {
            $connection = $this->factory->getConnection($message->getDriver());
        }
        $this->connection = $connection;
        parent::declare($message, $connection);
        $topicName = $message->getTopic();
        // 只有Topic才需要订阅
        if ($topicName) {
            $queueName = $message->getQueue();
            $queueEndPoint = $this->container->get(DriverFactory::class)->getDriverConfigByKey($message->getDriver(), 'queue_endpoint');
            $topic = $this->getTopic($topicName);
            $tag = $message->getTag();
            // 如果没有过滤标签，则所有订阅
            if (empty($tag)) {
                $subscriptionName = $queueName . '--all';
                $attributes = new SubscriptionAttributes($subscriptionName, $queueEndPoint . $queueName);
                $attributes->setContentFormat('SIMPLIFIED');
                try {
                    $topic->subscribe($attributes);
                } catch (MnsException $e) {
                    throw new MessageException('Subscribe failed: ' . $e->getMessage());
                }
            } else {
                $filterTags = explode(',', $tag);
                array_walk($filterTags, 'trim');
                foreach ($filterTags as $filterTag) {
                    $subscriptionName = $queueName . '-' . str_replace('_', '-', $filterTag);
                    $attributes = new SubscriptionAttributes($subscriptionName, $queueEndPoint . $queueName);
                    $attributes->setContentFormat('SIMPLIFIED');
                    $attributes->setFilterTag($filterTag);
                    try {
                        $topic->subscribe($attributes);
                    } catch (MnsException $e) {
                        throw new MessageException('Subscribe failed: ' . $e->getMessage());
                    }
                }
            }
        }
    }

    /**
     * Wait the tasks in concurrent handled, the max wait time is 5s.
     * @param int $interval The wait interval ms
     * @param int $count The wait count
     */
    protected function waitConcurrentHandled(?Concurrent $concurrent, int $interval = 10, int $count = 500): void
    {
        $index = 0;
        while ($concurrent && ! $concurrent->isEmpty()) {
            usleep($interval * 1000);
            if ($index++ > $count) {
                break;
            }
        }
    }

    protected function getConcurrent(string $driver): ?Concurrent
    {
        $concurrent = (int) $this->container->get(DriverFactory::class)->getDriverConfigByKey($driver, 'concurrent.limit', 0);
        if ($concurrent > 1) {
            return new Concurrent($concurrent);
        }

        return null;
    }

    protected function getCallback($queue, ConsumerMessageInterface $consumerMessage, $message)
    {
        return function() use ($queue, $consumerMessage, $message) {
            $data = $consumerMessage->unserialize($message->getMessageBody());
            try {
                $result = $consumerMessage->consumeMessage($data, $message);
            } catch (Throwable $exception) {
                if ($this->container->has(FormatterInterface::class)) {
                    $formatter = $this->container->get(FormatterInterface::class);
                    $this->logger->error($formatter->format($exception));
                } else {
                    $this->logger->error($exception->getMessage());
                }
                $result = Result::DROP;
            }
            // 消费成功后删除
            if ($result === Result::ACK) {
                $receiptHandle = $message->getReceiptHandle();
                $queue->deleteMessage($receiptHandle);
            }
            return true;
        };
    }
}
