<?php

declare(strict_types=1);

namespace Jing\Queue;

use Jing\Queue\Message\ProducerMessageInterface;
use Jing\Queue\Annotation\Producer;
use Hyperf\Di\Annotation\AnnotationCollector;
use PhpAmqpLib\Message\AMQPMessage;

class AMQPProducer extends AMQPBuilder
{
    public function produce(ProducerMessageInterface $producerMessage, bool $confirm = false, int $timeout = 5): bool
    {
        return retry(1, function () use ($producerMessage, $confirm, $timeout) {
            return $this->produceMessage($producerMessage, $confirm, $timeout);
        });
    }

    private function produceMessage(ProducerMessageInterface $producerMessage, bool $confirm = false, int $timeout = 5)
    {
        $result = false;

        $this->injectMessageProperty($producerMessage);
        $properties = [
            'content_type' => 'application/json',
            'delivery_mode' => AMQPMessage::DELIVERY_MODE_PERSISTENT,
        ];
        $message = new AMQPMessage($producerMessage->payload(), $properties);
        $connection = $this->factory->getConnection($producerMessage->getDriver());

        try {
            if ($confirm) {
                $channel = $connection->getConfirmChannel();
                //成功到达交换机时执行
                $channel->set_ack_handler(function(AMQPMessage $message) use (&$result) {
                    echo '入队成功逻辑' . PHP_EOL;
                    $result = true;
                });
                //nack,rabbitMQ内部错误时触发
                $channel->set_nack_handler(function(AMQPMessage $message) use (&$result) {
                    echo 'nack' . PHP_EOL;
                    $result = false;
                });
                //消息到达交换机,但是没有进入合适的队列,消息回退
                $channel->set_return_listener(function(
                    $reply_code,
                    $reply_text,
                    $exchange,
                    $routing_key,
                    AMQPMessage $message
                ) use ($channel, $connection, &$result) {
                    echo '消息退回, 入队失败逻辑' . PHP_EOL;
                    $channel->close();
                    $connection->releaseChannel($channel, true);
                    $result = false;
                });
            } else {
                $channel = $connection->getChannel();
            }
            $exchange = $producerMessage->getTopic();
            $routeKey = $exchange ? $producerMessage->getTag() : $producerMessage->getQueue();
            $channel->basic_publish($message, $exchange, $routeKey);
            if ($confirm) {
                $channel->wait_for_pending_acks_returns($timeout);
            }
        } catch (\Throwable $exception) {
            isset($channel) && $channel->close();
            throw $exception;
        }

        if ($confirm) {
            $connection->releaseChannel($channel, true);
        } else {
            $result = true;
            $connection->releaseChannel($channel);
        }

        return $result;
    }

    private function injectMessageProperty(ProducerMessageInterface $producerMessage)
    {
        if (class_exists(AnnotationCollector::class)) {
            /** @var null|\Jing\Queue\Annotation\Producer $annotation */
            $annotation = AnnotationCollector::getClassAnnotation(get_class($producerMessage), Producer::class);
            if ($annotation) {
                $annotation->driver && $producerMessage->setDriver($annotation->driver);
                $annotation->topic && $producerMessage->setTopic($annotation->topic);
                $annotation->queue && $producerMessage->setQueue($annotation->queue);
                $annotation->tag && $producerMessage->setTag($annotation->tag);
            }
        }
    }
}
