<?php

declare(strict_types=1);

namespace Jing\Queue\Annotation;

use Attribute;
use Hyperf\Di\Annotation\AbstractAnnotation;

/**
 * @Annotation
 * @Target({"CLASS"})
 */
#[Attribute(Attribute::TARGET_CLASS)]
class Consumer extends AbstractAnnotation
{
    /**
     * @var string
     */
    public $driver = 'default';

    /**
     * @var string
     */
    public $topic = '';

    /**
     * @var string
     */
    public $tag = '';

    /**
     * @var string
     */
    public $queue = '';

    /**
     * @var string
     */
    public $name = 'Consumer';

    /**
     * @var int
     */
    public $nums = 1;

    /**
     * @var null|bool
     */
    public $enable;

    /**
     * @var int
     */
    public $maxConsumption = 0;

    /**
     * @var int
     */
    public $waitTimeout = 0;
}
