<?php

declare(strict_types=1);

return [
    'default' => env('QUEUE_DRIVER', 'amqp'),
    'prefix' => env('QUEUE_NAME_PREFIX', ''),
    'drivers' => [
        'amqp' => [
            'host' => env('QUEUE_AMQP_HOST', 'localhost'),
            'port' => (int) env('QUEUE_AMQP_PORT', 5672),
            'user' => env('QUEUE_AMQP_USER', 'guest'),
            'password' => env('QUEUE_AMQP_PASSWORD', 'guest'),
            'vhost' => env('QUEUE_AMQP_VHOST', '/'),
            'producer' => Jing\Queue\AMQPProducer::class,
            'consumer' => Jing\Queue\AMQPConsumer::class,
            'open_ssl' => false,
            'concurrent' => [
                'limit' => 1,
            ],
            'pool' => [
                'connections' => 2,
            ],
            'params' => [
                'insist' => false,
                'login_method' => 'AMQPLAIN',
                'login_response' => null,
                'locale' => 'en_US',
                'connection_timeout' => 3,
                'read_write_timeout' => 6,
                'context' => null,
                'keepalive' => true,
                'heartbeat' => 3,
                'channel_rpc_timeout' => 0.0,
                'close_on_destruct' => false,
                'max_idle_channels' => 10,
            ]
        ],
        'mns' => [
            'key' => env('QUEUE_MNS_ACCESS_KEY'),
            'secret' => env('QUEUE_MNS_SECRET_KEY'),
            'endpoint' => env('QUEUE_MNS_ENDPOINT'),
            'queue' => env('QUEUE_NAME', 'mns-consumer'),
            'wait_seconds' => 30,
            'queue_endpoint' => env('QUEUE_MNS_QUEUEENDPOINT'),
            'producer' => Jing\Queue\MNSProducer::class,
            'consumer' => Jing\Queue\MNSConsumer::class,
            'concurrent' => [
                'limit' => 1,
            ],
        ]
    ]
];
