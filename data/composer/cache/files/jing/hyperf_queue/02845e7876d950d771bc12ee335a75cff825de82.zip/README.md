Jing Queue
------------------
Jing/HyperfQueue 是Jing内部Hyperf包，实现RabbitMQ和阿里云MNS队列统一操作。

# 依赖说明

* Hyperf: 2.x;
* hyperf/guzzle: 2.x;
* aliyun/aliyun-mns-php-sdk: >=1.0.0
* php-amqplib/php-amqplib: ^3.0

# 安装方式：

## ① 编辑配置文件

将以下内容增加到 composer.json：

```json
{
  "repositories": {
    "jing/hyperf_queue": {
      "type": "git",
      "url": "git@jgit.jingsocial.com:backend_dev/jing_hyperf_queue.git"
    }
  }
}
```

## ② 执行安装

运行命令：

```bash
composer require jing/hyperf_queue
```

## ③ 发布配置文件
```bash
php bin/hyperf.php vendor:publish jing/hyperf_queue
```

发布后会增加文件config/autuload/queue.php
```php
<?php

declare(strict_types=1);

return [
    'default' => env('QUEUE_DRIVER', 'amqp'),
    'prefix' => env('QUEUE_NAME_PREFIX', ''),
    'drivers' => [
        'amqp' => [
            'host' => env('QUEUE_AMQP_HOST', 'localhost'),
            'port' => (int) env('QUEUE_AMQP_PORT', 5672),
            'user' => env('QUEUE_AMQP_USER', 'guest'),
            'password' => env('QUEUE_AMQP_PASSWORD', 'guest'),
            'vhost' => env('QUEUE_AMQP_VHOST', '/'),
            'producer' => Jing\Queue\AMQPProducer::class,
            'consumer' => Jing\Queue\AMQPConsumer::class,
            'open_ssl' => false,
            'concurrent' => [
                'limit' => 1,
            ],
            'pool' => [
                'connections' => 2,
            ],
            'params' => [
                'insist' => false,
                'login_method' => 'AMQPLAIN',
                'login_response' => null,
                'locale' => 'en_US',
                'connection_timeout' => 3,
                'read_write_timeout' => 6,
                'context' => null,
                'keepalive' => true,
                'heartbeat' => 3,
                'channel_rpc_timeout' => 0.0,
                'close_on_destruct' => false,
                'max_idle_channels' => 10,
            ]
        ],
        'mns' => [
            'key' => env('QUEUE_MNS_ACCESS_KEY'),
            'secret' => env('QUEUE_MNS_SECRET_KEY'),
            'endpoint' => env('QUEUE_MNS_ENDPOINT'),
            'queue' => env('QUEUE_NAME', 'mns-consumer'),
            'wait_seconds' => 30,
            'queue_endpoint' => env('QUEUE_MNS_QUEUEENDPOINT'),
            'producer' => Jing\Queue\MNSProducer::class,
            'consumer' => Jing\Queue\MNSConsumer::class,
            'concurrent' => [
                'limit' => 1,
            ],
        ]
    ]
];

```
- default 指默认的driver，可以是drivers下的选项
- prefix Topic和Queue的名称前缀
- producer 指对应队列的生产类
- consumer 指对应队列的消费类

# 代码更新
## 新起一个版本号，提交到远程
```bash
git tag v1.0.0
git push origin v1.0.0
```

## 项目代码库需要更新包
```bash
composer update jing/hyperf_queue
```

# 项目使用

队列的生产和消费创建后，进程管理会根据类中的注解自动生成相应的消费进程启动。

## 创建生产

```bash
php bin/hyperf.php gen:queue-producer DemoProducer
```

生成队列生产类

```php
<?php

declare(strict_types=1);

namespace App\Queue\Producer;

use Jing\Queue\Annotation\Producer;
use Jing\Queue\Message\ProducerMessage;

/**
 * @Producer(driver="default", topic="jing-topic", tag="jing-topic-tag", type="direct", 'delay': 1, queue="jing-queue")
 */
#[Producer(driver: 'default', topic: 'jing-topic', tag: 'jing-topic-tag', type: 'direct', delay: 1, queue: 'jing-queue')]
class DemoProducer extends ProducerMessage
{
    public function __construct($data)
    {
        $this->payload = $data;
    }
}

```

- driver 默认是default，会自动匹配queue配置文件里设置的driver，也可以强制指定某个driver，那么不会自动切换。
- topic 指定topic名称（RabbitMQ中叫exchange），如果只发queue，不设置
- tag 指定过滤的标签（RabbitMQ中叫routekey），只有指定topic时才有意义
- type 处理exchanges的模式，只对RabbitMQ适用
- delay x-delayed-message的延时秒数，只对RabbitMQ适用
- queue 队列名称，如果不指定topic，在RabbitMQ中会以queue名称代替routekey

## 创建消费
```bash
php bin/hyperf.php gen:queue-consumer DemoConsumer
```

生成队列消费类

```php
<?php

declare(strict_types=1);

namespace App\Queue\Consumer;

use Jing\Queue\Result;
use Jing\Queue\Annotation\Consumer;
use Jing\Queue\Message\ConsumerMessage;

/**
 * @Consumer(driver= "default", topic="jing-topic", tag="jing-topic-tag", type="direct", queue="jing-queue", name="DemoConsumer", nums=1)
 */
#[Consumer(driver: "default", topic: 'jing-topic', tag: 'jing-topic-tag', type: 'direct', queue: 'jing-queue', name: "DemoConsumer", nums: 1)]
class DemoConsumer extends ConsumerMessage
{
    public function consumeMessage($data, $message): string
    {
        return Result::ACK;
    }
}

```

- driver 默认是default，会自动匹配queue配置文件里设置的driver，也可以强制指定某个driver，那么不会自动切换。
- topic 指定topic名称（RabbitMQ中叫exchange），，如果只发queue，不设置
- tag 指定过滤的标签（RabbitMQ中叫routekey），只有指定topic时才有意义，多个tag用逗号分隔
- type 处理exchanges的模式，只对RabbitMQ适用
- queue 队列名称，如果不指定topic，在RabbitMQ中会以queue名称代替routekey
- name 消费队列名称
- nums 消费队列进程数量

## 生产调用
```php
<?php
use App\Queue\Producer\DemoProducer;
use Jing\Queue\DriverFactory;
use Hyperf\Utils\ApplicationContext;

$message = new DemoProducer(['name' => 'demo', 'message' => 'test message']);
$producer = ApplicationContext::getContainer()->get(DriverFactory::class)->getDriver('producer');
$result = $producer->produce($message);
```