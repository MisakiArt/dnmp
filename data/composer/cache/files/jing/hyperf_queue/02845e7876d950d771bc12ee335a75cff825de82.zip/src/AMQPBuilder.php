<?php

declare(strict_types=1);

namespace Jing\Queue;

use Jing\Queue\Message\MessageInterface;
use Jing\Queue\Builder\AMQPExchangeBuilder;
use PhpAmqpLib\Channel\AMQPChannel;
use PhpAmqpLib\Exception\AMQPProtocolChannelException;
use Psr\Container\ContainerInterface;
use PhpAmqpLib\Wire\AMQPTable;
use PhpAmqpLib\Exchange\AMQPExchangeType;

class AMQPBuilder
{
    /**
     * @var ContainerInterface
     */
    protected $container;

    protected $poolFactory;

    /**
     * @var ConnectionFactory
     */
    protected $factory;

    public function __construct(ContainerInterface $container, AMQPConnectionFactory $factory)
    {
        $this->container = $container;
        $this->factory = $factory;
    }

    protected function getExchangeBuilder(string $exchange, string $type): AMQPExchangeBuilder
    {
        $exchange = (new AMQPExchangeBuilder())->setExchange($exchange)->setType($type);
        if ('x-delayed-message' === $type) {
            $arguments = new AMQPTable(['x-delayed-type' => AMQPExchangeType::FANOUT]);
            $exchange->setArguments($arguments);
        }
        return $exchange;
    }

    /**
     * @throws AMQPProtocolChannelException when the channel operation is failed
     */
    public function declare(MessageInterface $message, ?AMQPChannel $channel = null): void
    {
        $exchange = $message->getTopic();
        // 如果没有设置topic(exchange)，就不需要执行exchange_declare
        if (empty($exchange)) {
            return;
        }
        $releaseToChannel = false;
        if (!$channel) {
            $connection = $this->factory->getConnection($message->getDriver());
            $channel = $connection->getChannel();
            $releaseToChannel = true;
        }
        try {
            $type = $message->getType();
            $builder = $this->getExchangeBuilder($exchange, $type);
            $channel->exchange_declare($builder->getExchange(), $builder->getType(), $builder->isPassive(), $builder->isDurable(), $builder->isAutoDelete(), $builder->isInternal(), $builder->isNowait(), $builder->getArguments(), $builder->getTicket());
        } catch (\Throwable $exception) {
            if ($releaseToChannel && isset($channel)) {
                $channel->close();
            }
            throw $exception;
        }
        if ($releaseToChannel) {
            isset($connection) && $connection->releaseChannel($channel);
        }
    }
}
