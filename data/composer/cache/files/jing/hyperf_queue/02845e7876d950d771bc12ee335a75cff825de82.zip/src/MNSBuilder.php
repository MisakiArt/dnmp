<?php

declare(strict_types=1);

namespace Jing\Queue;

use Jing\Queue\Message\MessageInterface;
use Psr\Container\ContainerInterface;
use AliyunMNS\Requests\CreateTopicRequest;
use AliyunMNS\Requests\CreateQueueRequest;
use AliyunMNS\Exception\MnsException;
use AliyunMNS\Model\QueueAttributes;

class MNSBuilder
{
    /**
     * @var ContainerInterface
     */
    protected $container;

    /**
     * @var ConnectionFactory
     */
    protected $factory;

    /**
     * MNS连接
     */
    protected $connection;

    public function __construct(ContainerInterface $container, MNSConnectionFactory $factory)
    {
        $this->container = $container;
        $this->factory = $factory;
    }

    /**
     * 获取队列。
     * @param string $name
     * @return |null
     */
    protected function getQueue($name, $normalQueue = true)
    {
        $output = null;
        if (null != $name) {
            try {
                $output = $this->connection->getQueueRef($name, $normalQueue);
                $output->getAttribute();
            } catch (MnsException $e) {
                $this->createQueue($name);
                $output = $this->connection->getQueueRef($name, $normalQueue);
            }
        }
        return $output;
    }

    /**
     * 创建队列.
     * @param string $name 队列名
     * @return boolean
     */
    protected function createQueue($name)
    {
        try {
            $request = new CreateQueueRequest($name, new QueueAttributes(null, null, 1296000));
            $response = $this->connection->createQueue($request);
            return $response->isSucceed();
        } catch (MnsException $e) {
            throw $e;
        }
    }

    /**
     * 获取主题。
     * @param $name
     * @return |null
     */
    protected function getTopic($name)
    {
        $output = null;
        if (null != $name) {
            try {
                $output = $this->connection->getTopicRef($name);
                $output->getAttribute();
            } catch (MnsException $e) {
                $this->createTopic($name);
                $output = $this->connection->getTopicRef($name);
            }
        }
        return $output;
    }

    /**
     * 创建主题.
     * @param string $name 主题名
     * @return boolean
     */
    protected function createTopic($name)
    {
        try {
            $request = new CreateTopicRequest($name);
            $response = $this->connection->createTopic($request);
            return $response->isSucceed();
        } catch (MnsException $e) {
            throw $e;
        }
    }

    /**
     * 生成MNS Queue和Topic
     */
    public function declare(MessageInterface $message, $connection = null): void
    {
        if (!$connection) {
            $connection = $this->factory->getConnection($message->getDriver());
        }
        $this->connection = $connection;
        try {
            $queue = $message->getQueue();
            $this->getQueue($queue);
            $topic = $message->getTopic();
            if (!empty($topic)) {
                $this->getTopic($topic);
            }
        } catch (MnsException $exception) {
        }
    }
}
