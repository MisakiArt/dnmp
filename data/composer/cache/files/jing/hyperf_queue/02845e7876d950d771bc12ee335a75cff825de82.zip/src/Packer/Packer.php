<?php

declare(strict_types=1);

namespace Jing\Queue\Packer;

use Hyperf\Contract\PackerInterface;

interface Packer extends PackerInterface
{
}
