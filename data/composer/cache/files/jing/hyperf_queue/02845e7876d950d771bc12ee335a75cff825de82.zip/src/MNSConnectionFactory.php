<?php

declare(strict_types=1);

namespace Jing\Queue;

use AliyunMNS\Client;
use Psr\Container\ContainerInterface;

class MNSConnectionFactory extends ConnectionFactory
{
    public function __construct(ContainerInterface $container)
    {
        parent::__construct($container);
    }

    public function getConnection(string $driver)
    {
        $config = $this->getConfig($driver);
        $endPoint = $config['endpoint'] ?? '';
        $accessId = $config['key'] ?? '';
        $accessKey = $config['secret'] ?? '';

        return new Client($endPoint, $accessId, $accessKey);
    }
}
