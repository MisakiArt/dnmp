<?php

declare(strict_types=1);

namespace Jing\Queue\Message;

interface ConsumerMessageInterface extends MessageInterface
{
    public function consumeMessage($data, $message): string;

    public function isEnable(): bool;

    public function setEnable(bool $enable);

    public function getMaxConsumption(): int;

    public function setMaxConsumption(int $maxConsumption);

    public function getWaitTimeout();

    public function setWaitTimeout($timeout);
}
