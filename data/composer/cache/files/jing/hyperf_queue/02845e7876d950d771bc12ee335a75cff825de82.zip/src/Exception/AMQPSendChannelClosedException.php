<?php

declare(strict_types=1);

namespace Jing\Queue\Exception;

class AMQPSendChannelClosedException extends \RuntimeException
{
}
