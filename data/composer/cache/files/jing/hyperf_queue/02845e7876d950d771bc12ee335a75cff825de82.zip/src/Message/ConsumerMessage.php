<?php

declare(strict_types=1);

namespace Jing\Queue\Message;

use Jing\Queue\Packer\Packer;
use Hyperf\Utils\ApplicationContext;
use Psr\Container\ContainerInterface;

abstract class ConsumerMessage extends Message implements ConsumerMessageInterface
{
    /**
     * @var ContainerInterface
     */
    public $container;

    /**
     * @var bool
     */
    protected $enable = true;

    /**
     * @var int
     */
    protected $maxConsumption = 0;

    /**
     * @var float|int
     */
    protected $waitTimeout = 0;

    public function consumeMessage($data, $message): string
    {
        return $this->consume($data);
    }

    public function consume($data): string
    {
        return 'success';
    }

    public function unserialize(string $data)
    {
        $container = ApplicationContext::getContainer();
        $packer = $container->get(Packer::class);
        return $packer->unpack($data);
    }

    public function isEnable(): bool
    {
        return $this->enable;
    }

    public function setEnable(bool $enable): self
    {
        $this->enable = $enable;
        return $this;
    }

    public function getMaxConsumption(): int
    {
        return $this->maxConsumption;
    }

    public function setMaxConsumption(int $maxConsumption)
    {
        $this->maxConsumption = $maxConsumption;
        return $this;
    }

    public function getWaitTimeout()
    {
        return $this->waitTimeout;
    }

    public function setWaitTimeout($timeout)
    {
        $this->waitTimeout = $timeout;
        return $this;
    }
}
