<?php

namespace Jing\Hyperf\Pii\lib;

class Aes
{

    protected static $isIv = false;

    protected static $base64 = true;

    protected static $method = 'aes-256-cbc';

    protected static $iv = 'a517167af64d5944';

    protected static $options = OPENSSL_RAW_DATA;
    
    protected static $secret_key = 'IXqQNM96p7Hu24zx';

    /**
     * @param $data
     *
     * @return array
     * 数据加密
     */
    public static function encrypt($data)
    {
        if (!$data && !is_numeric($data)) {
            return '';
        }
        if (self::$isIv) {
            $ivlen = openssl_cipher_iv_length(self::$method);
            $iv = openssl_random_pseudo_bytes($ivlen);
            $iv = bin2hex($iv);
            if (strlen($iv) > $ivlen) {
                $iv = substr($iv, 0, $ivlen);
            }
        } else {
            $iv = self::$iv;
        }
        if (is_array($data)) {
            $data = json_encode($data);
        }
        $sign = self::signDealEncode(openssl_encrypt($data, self::$method, self::$secret_key, self::$options, $iv));
        return self::$isIv ? ['sign' => $sign, 'iv' => $iv] : $sign;
    }

    /**
     * @param $method
     * 设置算法类型
     */
    public static function setMethod($method)
    {
        self::$method = $method;
    }

    /**
     * @param $key
     * 设置加密key
     */
    public static function setKey($key)
    {
        self::$secret_key = $key;
    }

    /**
     * @param bool $status
     */
    public static function setBase64(bool $status = true)
    {
        self::$base64 = $status;
    }

    /**
     * @param        $sign
     * @param string $iv
     *
     * @return false|string
     * 数据解密
     */
    public static function decrypt($sign, string $iv = '')
    {
        if (!$iv) {
            $iv = self::$iv;
        }
        $result = openssl_decrypt(self::signDealDecode($sign), self::$method, self::$secret_key, self::$options, $iv);
        if (!mb_detect_encoding($result, ['UTF-8']) || $result === false) {
            return false;
        }
        return $result;
    }

    /**
     * @param $sign
     *
     * @return false|string
     */
    public static function signDealEncode($sign)
    {
        return self::$base64 ? base64_encode($sign) : $sign;
    }

    /**
     * @param $sign
     *
     * @return false|string
     */
    public static function signDealDecode($sign)
    {
        return self::$base64 ? base64_decode($sign) : $sign;
    }
}
