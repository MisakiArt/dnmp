<?php

namespace Jing\Hyperf\Pii\lib;

class HttpCurl
{
    /**
     * http 请求
     *
     * @param string $url      地址
     * @param array  $body     参数
     * @param array  $headers  header 头
     * @param bool   $checkSsl 是否校验证书
     *
     * @return bool|string
     */
    public static function post(string $url, array $body, array $headers = [], bool $checkSsl = false)
    {
        $c = curl_init();

        if (!$checkSsl) {
            curl_setopt($c, CURLOPT_SSL_VERIFYPEER, $checkSsl);
        }

        if (count($headers) > 0) {
            curl_setopt($c, CURLOPT_HTTPHEADER, $headers);
        }

        curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($c, CURLOPT_POST, true);
        curl_setopt($c, CURLOPT_POSTFIELDS, json_encode($body));
        curl_setopt($c, CURLOPT_URL, $url);

        $ret = curl_exec($c);
        if ($err = curl_error($c)) {
            return $err;
        }

        curl_close($c);
        return $ret;
    }
}
