<?php

namespace Jing\Hyperf\Pii;

use Exception;

class PiiLogic extends Pii
{
    /**
     *  pii 加密
     *
     * @param array  $data
     * @param        $domain
     * @param string $mid
     * @param string $type
     *
     * @return array
     * @throws Exception
     */
    public function aesEncode(array $data, $domain, string $mid = '', string $type = 'custom_field')
    {
        $result = self::processing($mid, $data, 1, $type, $domain);

        return self::after(self::aesEncrypt(self::dataDeal($result)), $data);
    }

    /**
     *  pii 解密
     *
     * @param array  $data
     * @param        $domain
     * @param string $mid
     * @param string $type
     *
     * @return array
     * @throws Exception
     */
    public function aesDecode(array $data, $domain, string $mid = '', string $type = 'custom_field')
    {
        $result = self::processing($mid, $data, 2, $type, $domain);
        
        return self::after(self::aesDecrypt(self::dataDeal($result)), $data);
    }
}
