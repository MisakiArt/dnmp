<?php

namespace Jing\Hyperf\Pii;

use Closure;
use Exception;
use Throwable;
use Hyperf\Redis\RedisProxy;
use Jing\Hyperf\Pii\lib\Aes;
use Jing\Hyperf\Pii\lib\HttpCurl;

class Pii
{
    /**
     * RedisProxy 实例
     *
     * RedisProxy
     *
     * @var $redis
     */
    private $redis;

    /**
     * redis 前缀
     *
     * @var string
     */
    private $prefix = '';

    /**
     * @var string
     */
    private $mid = '';

    /**
     * @var string
     *
     * 第一期只有custom_field
     */
    private $type = '';

    /**
     * @var string
     *
     *  internal domain
     */
    private $domain = '';

    protected $encode = true;

    /**
     * @var int[]
     *  //排除正常逻辑的数据
     */
    protected $excludes = [34];

    protected $allRules;

    /**
     * @var
     * 1:加密，2:解密,3:打码
     */
    protected $action;

    /**
     * @var int
     *  要处理的数组的维度目前只支持1,2维
     */
    protected $dimension = 1;

    /**
     * @var bool
     *  是否需要callApi true:需要 false:不需要
     */
    protected $needDeal = true;

    /**
     * //密文识别符
     */
    const SEPARATOR = "_ENCODE_";

    /**
     *  pii 配置缓存
     */
    const CACHE_PII_SETTING_KEY = 'JING_PII_SETTINGS';

    /**
     * pii 规则缓存
     */
    const CACHE_PII_RULE_KEY = 'JING_PII_RULE_';

    /**
     *
     */
    const CACHE_PII_THIRD_SECRET_KEY = 'JING_PII_THIRD_SECRETKEY';

    /**
     * pii 配置internal api 地址
     */
    const API_PII_SETTING_INFO = '/internal/pii/getPiiSettingInfo';

    /**
     * pii 规则internal api 地址
     */
    const API_PII_ALL_RULES = '/internal/pii/getAllRules';

    /**
     * pii 获取第三方key
     */
    const API_PII_THIRD_SECRET = '/internal/pii/getThirdPartyKey';

    /**
     * pii 获取私钥
     */
    const API_PII_PRIVATE_KEY = '/internal/pii/getPrivateKey';

    /**
     * constructor.
     *
     * @param RedisProxy $redis
     * @param string     $prefix
     */
    public function __construct(RedisProxy $redis, string $prefix = '')
    {
        $this->redis = $redis;
        $this->prefix = $prefix;
    }

    /**
     * @return mixed
     * 获取用户 mid
     */
    protected function getMid()
    {
        return $this->mid;
    }

    /**
     * @param $mid
     *
     * @return mixed
     * 设置用户 mid
     */
    protected function setMid($mid)
    {
        return $this->mid = $mid ?: self::getMid();
    }

    /**
     * @return mixed
     * 获取加密的type
     */
    protected function getType()
    {
        return $this->type;
    }

    /**
     * @param $mid
     *
     * @return mixed
     * 设置加密的type
     */
    protected function setType($type)
    {
        return $this->type = $type ?: self::getType();
    }

    /**
     * @return string
     */
    protected function getDomain(): string
    {
        return $this->domain;
    }

    /**
     * @param $domain
     *
     * @return mixed
     */
    protected function setDomain($domain)
    {
        return $this->domain = $domain ?: self::getDomain();
    }

    /**
     * getPiiSettingKey
     * @return string
     */
    protected function getPiiSettingKey(): string
    {
        return $this->prefix
            ? $this->prefix . self::CACHE_PII_SETTING_KEY
            : self::CACHE_PII_SETTING_KEY;
    }

    /**
     * 获取pii rule的cache key
     *
     * @param        $mid
     * @param string $type
     *
     * @return string
     */
    protected function getRuleCacheKey($mid, string $type = 'custom_field'): string
    {
        return $this->prefix
            ? ($this->prefix . self::CACHE_PII_RULE_KEY . $mid . ':' . $type)
            : (self::CACHE_PII_RULE_KEY . $mid . ':' . $type);
    }

    /**
     * getPiiSettingKey
     * @return string
     */
    protected function getThirdPartyKey(): string
    {
        return $this->prefix
            ? $this->prefix . self::CACHE_PII_THIRD_SECRET_KEY
            : self::CACHE_PII_THIRD_SECRET_KEY;
    }

    protected function callInternalApi($uri, $method = 'POST', $params = [])
    {
        try {
            $rsp = json_decode(
                HttpCurl::$method(
                    rtrim(self::getDomain(), '/') . $uri,
                    $params,
                    ['Content-Type' => 'application/json']
                ), true);

            if (isset($rsp['code']) && $rsp['code'] == 0) {
                return $rsp['data'];
            }
        } catch (\Exception $e) {
            return false;
        }
        return false;
    }

    /**
     * @param $mid
     * @param $data
     * @param $action
     * @param $type
     * @param $domain
     *
     * @return array|mixed
     * 数据处理
     */
    protected function processing($mid, $data, $action, $type, $domain)
    {
        self::setMid($mid);
        self::setType($type);
        self::setDomain($domain);
        $this->action = $action;
        $result = self::before($data);
        if (!$this->needDeal) {
            $this->needDeal = true;
            return $result;
        }
        return $result;
    }


    /**
     * @param $data
     *
     * @return array
     * @throws Exception
     * 格式化数据
     */
    protected function dataDeal($data)
    {
        if (self::getMid()) {
            return ['mid' => $this->mid, 'type' => $this->type, 'data' => $data];
        } else {
            throw new Exception("Have no right to access");
        }
    }

    /**
     * @return bool
     * 获取指定的mid是否开启了PII加密配置及是否有需要加盟的filed
     */
    public function checkMidPiiEnabled(): bool
    {
        if (in_array(self::getMid(), $this->excludes)) {
            return true;
        }

        $setting = self::getPiiSettingInfo(self::getMid());
        if (isset($setting['JING_PII']) || !$setting['key_type']) {
            return false;
        }
        $rules = self::getAllRules(self::getMid(), self::getType());
        return !(isset($rules['JING_PII']) || empty($rules));

    }


    /**
     * @param $mid
     *
     * @return mixed
     * 获取用户的pii配置信息
     */
    protected function getPiiSettingInfo($mid)
    {
        $settingInfo = $this->redis->hget(self::getPiiSettingKey(), $mid);
        if (isset($settingInfo['JING_PII'])) {
            return false;
        }
        if ($settingInfo == null) {
            $settingInfo = self::callInternalApi(self::API_PII_SETTING_INFO, 'POST', ["mid" => $mid]);
        } else {
            $settingInfo = json_decode($settingInfo, true);
        }
        return $settingInfo;
    }

    /**
     * 获取加密filed配置信息
     * 设置了字段加密的缓存,key为custom_field的id，value为加密打码规则：
     * [
     *    391 => {
     *        "jing_uuid": "zhiVSEfFVQiwSmo8rzziz",
     *        "mid": 222,
     *        "owner_id": 360,
     *        "type": "custom_field",
     *        "field_identity_value": "6815",
     *        "field_cache_key": "name",
     *        "field_cache_code": "name",
     *        "pii_show_config": "{\"show_format\": \"captcha\", \"captcha_format\": \"prefix\", \"captcha_length\": 1}"
     *    }
     * ]
     * 没设置字段加密的缓存：[0 => ['JING_PII' => 1]]
     *
     * @param        $mid
     * @param string $type
     *
     * @return array|bool|mixed
     */
    public function getAllRules($mid, string $type = 'custom_field')
    {
        $rule = $this->redis->hgetall(self::getRuleCacheKey($mid, $type));
        if (isset($rule[0]) && count($rule) === 1) {
            return false;
        }
        $rules = [];
        if ($rule) {
            foreach ($rule as $k => $v) {
                if ($k == 0) {
                    continue;
                }
                $v = json_decode($v, true);
                $rules[$v['field_cache_code']] = $v['pii_show_config'];
            }
        } else {
            $rules = self::callInternalApi(self::API_PII_ALL_RULES, 'POST', ["mid" => $mid, 'type' => $type]);
        }
        $this->allRules = $rules;
        return $rules;
    }

    /**
     * @param $data
     *
     * @return array
     * 对一维数组格式化及过滤处理
     */
    protected function singleDataFormat($data)
    {
        $row = [];
        foreach ($this->allRules as $key => $value) {
            if (isset($data[$key]) && !is_array($data[$key])) {
                $rw = self::filterEncoded($data[$key]);
                if ($rw) {
                    $row[$key] = $rw;
                }
            }
        }
        return $row;
    }

    /**
     * @param $str
     *
     * @return string
     * 对( - 加密的方法里传入已经加密的数据| - 解密的方法里传入已经是明文的数据)
     * 进行相应的判别并进行过滤处理
     */
    protected function filterEncoded($str)
    {
        $arr = explode(self::SEPARATOR, $str);//处理需要解密的数据
        $status = isset($arr[2]);
        switch ($this->action) {
            case 1:
                $str = $status ? '' : $str;
                break;
            case 2:
                $str = $status ? $str : '';
                break;
        }
        return $str;
    }

    /**
     * @param $data
     *
     * @return mixed
     * 在调用internal接口之前进行相应的配置判断，并根据用户的filed配置及传入的$data的状态(密文or明文)
     * 进行过滤处理,只会把需要处理的数据发送给internal接口，减少数据传输，接口调用频次。
     * 数据拆分
     */
    protected function before($data)
    {
        if (!self::checkMidPiiEnabled()) {
            $this->needDeal = false;
            return $data;
        }
        if (count(array_filter($data, 'is_array')) !== count($data)) {
            $row = self::singleDataFormat($data);
            $this->dimension = 1;
        } else {
            $this->dimension = 2;
            foreach ($data as $key => $value) {
                $rw = self::singleDataFormat($value);
                if (!empty($rw)) {
                    $row[$key] = $rw;
                }
            }
        }
        if (empty($row)) {
            $this->needDeal = false;
            return $data;
        }
        return $row;
    }

    /**
     * @param $originData
     * @param $data
     *
     * @return array
     * 对经过internal接口处理过的数据和用户传入的原始数据进行重新组装
     * 数据组装
     */
    protected function after($originData, $data): array
    {
        if ($this->dimension == 1) {
            $result = array_merge($data, $originData);
        } else {
            foreach ($originData as $key => $value) {
                foreach ($value as $k => $v) {
                    if (isset($data[$key][$k])) {
                        $data[$key][$k] = $v;
                    }
                }
            }
            $result = $data;
        }
        $this->needDeal = true;//防止命令行，多mid循环使用
        return $result;
    }

    /**
     * 加密数组
     * $data传入需要加密的一维数组
     * 返回一个已经加密的一维数组：['公文' => '密文', ...]
     *
     * @param int   $mid
     * @param array $data
     *
     * @return false|mixed
     */
    public function encodeArray(int $mid, array $data)
    {
        $post = [
            'mid' => $mid,
            'data' => array_unique($data),
        ];
        return self::callInternalApi(self::$encodeArray, 'POST', $post);
    }

    /**
     * 加密数组
     * $data传入需要加密的一维数组
     * 返回一个已经加密的一维数组：['密文' => '公文', ...]
     *
     * @param int   $mid
     * @param array $data
     *
     * @return false|mixed
     */
    public function decodeArray(int $mid, array $data)
    {
        $post = [
            'mid' => $mid,
            'data' => array_unique($data),
        ];
        return self::callInternalApi(self::$decodeArray, 'POST', $post, true);
    }

    /**
     *数据加密
     */
    public function aesEncrypt($contentarr)
    {
        try {
            $code = $this->getContentAndDeal($contentarr, function ($content) {
                return Aes::encrypt($content);
            });
        } catch (Throwable $th) {
            $code = $th->getMessage();
        }
        return $code;
    }

    /**
     *数据解密
     * @throws Exception
     */
    public function aesDecrypt($contentarr)
    {
        $this->encode = false;//解密
        return $this->getContentAndDeal($contentarr, function ($content) {
            return Aes::decrypt($content);
        });
    }

    /**
     * @param Closure $closure
     *
     * @return false|string
     * 获取请求参数并处理
     * @throws Exception
     */
    protected function getContentAndDeal($contentarr, Closure $closure)
    {
        $code = [];
        if (is_array($contentarr)) {
            if (isset($contentarr['mid']) && isset($contentarr['data']) && isset($contentarr['type'])) {
                $data = $contentarr['data'];
                $mid = $contentarr['mid'];
                $type = $contentarr['type'];
                if ($this->encode && in_array($mid, $this->excludes)) {
                    return $data;
                }
                $pii = self::getPiiSettingInfo($mid);//获取配置信息
                if (isset($pii['key_type']) && $pii['key_type']) {
                    $rules = self::getAllRules($mid, $type);
                    if ($rules) {
                        switch ($pii['key_type']) {
                            case 'api':
                                $secretKey = self::getThirdPartyInfo($mid);
                                break;
                            default:
                                $secretKey = self::getPrivateKey($mid);
                                break;
                        }
                        Aes::setKey($secretKey);
                        if (count($data) != count($data, 1)) {
                            $datas = $data;
                            $rows = [];
                            foreach ($datas as $k => $data) {
                                $code = $this->singleContentDeal($rules, $data, $closure);
                                $rows[$k] = array_merge($data, $code);
                            }
                            return $rows;
                        } else {
                            $code = $this->singleContentDeal($rules, $data, $closure);
                        }
                    }
                }
                $code = array_merge($data, $code);
            }
        }
        return $code;
    }

    /**
     * @param         $rules
     * @param         $data
     * @param Closure $closure
     *
     * @return array
     * 一维数组处理
     */
    protected function singleContentDeal($rules, $data, Closure $closure)
    {
        $code = [];
        foreach ($rules as $key => $rule) {
            if (isset($data[$key]) && ($data[$key] || is_numeric($data[$key]))) {
                $code[$key] = self::filterEncodedv2($data[$key], $closure);
            }
        }
        return $code;
    }

    /**
     * @param         $str
     * @param Closure $closure
     *
     * @return mixed
     */
    protected function filterEncodedv2($str, Closure $closure)
    {
        $arr = explode(self::SEPARATOR, $str);//处理需要解密的数据
        if ($this->encode) {//加密
            if (isset($arr[2])) {
                return $str;
            }
            return self::SEPARATOR . $closure($str) . self::SEPARATOR;
        } else {//解密
            if (isset($arr[2])) {
                $result = $closure($arr[1]);
                // 判断乱码
                if (json_encode($result) === false) {
                    return $str;
                }
                return $result || is_numeric($result) ? $result : $str;
            } else {
                return $str;
            }
        }

    }

    /**
     * 获取第三方key
     *
     * @param $mid
     *
     * @return mixed
     * @throws Exception
     */
    public function getThirdPartyInfo($mid)
    {
        $secret = $this->redis->hget(self::getThirdPartyKey(), $mid);
        if (isset($secret['key'])) {
            return $secret['key'];
        }

        return self::callInternalApi(self::API_PII_THIRD_SECRET, 'POST', ["mid" => $mid]);
    }

    /**
     * 获取私钥
     *
     * @param $mid
     *
     * @return mixed
     * @throws Exception
     */
    public function getPrivateKey($mid)
    {
        return self::callInternalApi(self::API_PII_PRIVATE_KEY, 'POST', ["mid" => $mid]);
    }

}
