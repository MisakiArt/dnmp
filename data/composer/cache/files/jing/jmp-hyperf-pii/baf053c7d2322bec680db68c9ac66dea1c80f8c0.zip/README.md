Jing Hyperf pii
------------------
jing/jmp-hyperf-pii 是Jing内部Hyperf包，实现平台 Pii 功能

# 依赖说明

* Hyperf: 2.x;

# 安装方式：

## ① 编辑配置文件

将以下内容增加到 composer.json：

```json
{
  "repositories": {
    "jing/jmp-hyperf-pii": {
      "type": "git",
      "url": "git@jgit.jingsocial.com:backend_dev/jmp-hyperf-pii.git"
    }
  }
}
```

## ② 执行安装

运行命令：

```bash
composer require jing/jmp-hyperf-pii
```

## 项目代码库需要更新包
```bash
composer update jing/jmp-hyperf-pii
```

### 代码来源于此项目: [backend_dev/jmp-pii](https://jgit.jingsocial.com:8000/backend_dev/jmp-pii)
