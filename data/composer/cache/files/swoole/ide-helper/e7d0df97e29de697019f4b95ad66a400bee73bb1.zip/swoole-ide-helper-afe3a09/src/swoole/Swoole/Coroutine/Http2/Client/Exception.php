<?php

declare(strict_types=1);

namespace Swoole\Coroutine\Http2\Client;

class Exception extends \Swoole\Exception
{
}
