<?php

declare(strict_types=1);

namespace Swoole\Http;

class Server extends \Swoole\Server
{
}
