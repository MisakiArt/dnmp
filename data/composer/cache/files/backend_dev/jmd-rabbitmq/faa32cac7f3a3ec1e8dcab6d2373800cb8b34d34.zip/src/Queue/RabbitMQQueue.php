<?php

namespace Jing\JmdRabbitMq\Queue;

use Illuminate\Contracts\Queue\Queue as QueueContract;
use Illuminate\Queue\Events\WorkerStopping;
use Illuminate\Queue\InvalidPayloadException;
use Illuminate\Queue\Queue;
use Illuminate\Queue\QueueManager;
use Interop\Amqp\AmqpConnectionFactory;
use Interop\Amqp\AmqpContext;
use Interop\Amqp\AmqpMessage;
use Interop\Amqp\AmqpQueue;
use Interop\Amqp\AmqpTopic;
use Interop\Amqp\Impl\AmqpBind;
use PhpAmqpLib\Wire\AMQPTable;
use Psr\Log\LoggerInterface;
use RuntimeException;
use Jing\JmdRabbitMq\Queue\Jobs\RabbitMQJob;
use Illuminate\Support\Facades\Config;

class RabbitMQQueue extends Queue implements QueueContract
{
    /**
     * Used for retry logic, to set the retries on the message metadata instead of the message body.
     */
    const ATTEMPT_COUNT_HEADERS_KEY = 'attempts_count';

    protected $sleepOnError;

    protected $queueOptions;
    protected $exchangeOptions;

    private $declaredExchanges = [];
    private $declaredQueues = [];

    public $retryTime=0;
    public $popRetryTime = 0;
    /**
     * 默认队列.
     *
     * @var string
     */
    protected $default;

    /**
     * @var AmqpContext
     */
    private $context;
    private $retryAfter;
    private $correlationId;
    public $topicMap = [];
    public $queueMap = [];
    public $isInit = 0;
    public $consumerMap = [];

    /** @var AmqpConnectionFactory $factory */
    public $factory;

    public $job;

    public function __construct(AmqpContext $context, array $config,$factory)
    {
        $this->context = $context;

        $this->queueOptions = $config['options']['queue'];
        $this->queueOptions['arguments'] = isset($this->queueOptions['arguments']) ? json_decode($this->queueOptions['arguments'], true) : [];

        $this->exchangeOptions = $config['options']['exchange'];

        $this->sleepOnError = $config['sleep_on_error'] ?? 5;

        $this->default = $config['queue'];
        $this->factory = $factory;
    }

    public function resetConnection()
    {
        $this->context = $this->factory->createContext();
    }

    /** @inheritdoc */
    public function size($queueName = null): int
    {
        /** @var AmqpQueue $queue */
        list($queue) = $this->declareEverything($queueName);

        return $this->context->declareQueue($queue);
    }

    /** @inheritdoc */
    public function push($job, $data = '', $queue = null)
    {
        $this->retryTime = 0;
        $this->job = $job;
        return $this->pushRaw($this->createPayload($job, $data), $queue, []);
    }

    /** @inheritdoc */
    public function pushRaw($payload, $queueName = null, array $options = [])
    {
        $param = [$payload,$queueName,$options];
        try {
            if (!empty($this->job->sendToNormalQueue)) {
                if (!is_array($payload)) {
                    $data = json_decode($payload, true);
                }
                $payload = json_encode(['queue' => $queueName, 'data' => $data]);
                $queueName = self::getAggQueueName();
            }

            $routingKey = '';
            $exchangeName = $this->getTopicMappingValue($queueName, 'topicName');
            $filterTag = $this->getTopicMappingValue($queueName, 'filterTag');
            if ( isset($this->job->sendToTopic) && $this->job->sendToTopic && $exchangeName && $filterTag && is_string($exchangeName) && is_string($filterTag)) {
                $payload = json_encode($payload);
                $this->exchangeOptions['name'] = $this->getQueue($exchangeName);
                $routingKey = $filterTag;
                $this->queueOptions['bind'] = false;
            } else {
                $this->exchangeOptions['name'] = null;
            }
            /**
             * @var AmqpTopic $topic
             * @var AmqpQueue $queue
             */
            list($queue, $topic) = $this->declareEverything($this->getQueue($queueName));
            if (empty($routingKey)) {
                $routingKey = $queue->getQueueName();
            }
            $message = $this->context->createMessage($payload);
            $message->setRoutingKey($routingKey);
            $message->setCorrelationId($this->getCorrelationId());
            $message->setContentType('application/json');
            $message->setDeliveryMode(AmqpMessage::DELIVERY_MODE_PERSISTENT);

            if ($this->retryAfter !== null) {
                $message->setProperty(self::ATTEMPT_COUNT_HEADERS_KEY, $this->retryAfter);
            }

            $producer = $this->context->createProducer();
            if (isset($options['delay']) && $options['delay'] > 0) {
                $message->setProperty('x-delay',$options['delay'] * 1000);
//                $producer->setDeliveryDelay($options['delay'] * 1000);
            }
            $producer->send($topic, $message);

            return $message->getCorrelationId();
        } catch (\Exception $exception) {
            /** @var LoggerInterface $logger */
            $logger = $this->container['log'];
            $logger->info($exception->getMessage());
            $this->container['events']->dispatch(WorkerStopping::class);
            $this->resetConnection();
            if ($this->retryTime<3) {
                $this->retryTime++;
                $logger->info("rabbit mq push error $queueName retry time :".$this->retryTime);
                return $this->pushRaw(...$param);
            } else {
                $logger->error("rabbit mq push error $queueName retry fail:".json_encode($payload));
            }
            $this->reportConnectionError('pushRaw', $exception);
            return null;
        }
    }

    /** @inheritdoc */
    public function later($delay, $job, $data = '', $queue = null)
    {
        $this->retryTime = 0;
        $this->job = $job;
        return $this->pushRaw($this->createPayload($job, $data), $queue, ['delay' => $this->secondsUntil($delay)]);
    }

    public function pop($queueName = null)
    {
        try {
            $topic = $this->getTopicMappingValue($queueName, 'topicName');
            $filterTags = $this->getTopicMappingValue($queueName, 'filterTag');
            $routeKeys = [];
            //多个filterTag信息 循环消费
            if ( $topic && $filterTags) {
                $this->exchangeOptions['name'] = $this->getQueue($topic);
                $this->queueOptions['bind'] = false;
                if (is_array($filterTags)) {
                    $routeKeys = $filterTags;
                } elseif(is_string($filterTags)) {
                    $routeKeys = [$filterTags];
                }
            }
            /** @var AmqpQueue $queue */
            list($queue, $topic) = $this->declareEverything($this->getQueue($queueName));

            if (!$this->isInit) {
                //bind route key
                if (!empty($routeKeys)) {
                    foreach ($routeKeys as $routeKey) {
                        $this->context->bind(new AmqpBind($queue, $topic, $routeKey));
                    }
                }
                $this->isInit = 1;
            }
            if (!isset($this->consumerMap[$queue->getQueueName()])) {
                $consumer = $this->context->createConsumer($queue);
            } else {
                $consumer = $this->consumerMap[$queue->getQueueName()];
            }

            if ($message = $consumer->receiveNoWait()) {
                return new RabbitMQJob($this->container, $this, $consumer, $message);
            }
        } catch (\Exception $exception) {
            /** @var LoggerInterface $logger */
            $logger = $this->container['log'];
            $logger->error("rabbit mq push error:".$exception->getMessage().' retry Time:'.$this->popRetryTime);
            $this->popRetryTime++;
            if ($this->popRetryTime<20) {
                sleep(2);
                $this->container['events']->dispatch(WorkerStopping::class);
                $this->resetConnection();
                $this->pop($queueName);
            } else {
                //出现异常让其退出
                throw new \Exception("Lost connection");
            }
        }
    }


    /**
     * Sets the attempts member variable to be used in message generation.
     *
     * @param int $count
     *
     * @return void
     */
    public function setAttempts(int $count)
    {
        $this->retryAfter = $count;
    }

    /**
     * Retrieves the correlation id, or a unique id.
     *
     * @return string
     */
    public function getCorrelationId(): string
    {
        return $this->correlationId ?: uniqid('', true);
    }

    /**
     * Sets the correlation id for a message to be published.
     *
     * @param string $id
     *
     * @return void
     */
    public function setCorrelationId(string $id)
    {
        $this->correlationId = $id;
    }

    /**
     * @return AmqpContext
     */
    public function getContext(): AmqpContext
    {
        return $this->context;
    }

    /**
     * @param string $queueName
     *
     * @return array [Interop\Amqp\AmqpQueue, Interop\Amqp\AmqpTopic]
     */
    private function declareEverything(string $queueName = null): array
    {
        $queueName = $queueName ?? $this->queueOptions['name'];
        $exchangeName = $this->exchangeOptions['name'] ?? $queueName;

        if (empty($this->topicMap[$exchangeName])) {
            $topic = $this->context->createTopic($exchangeName);
            if ($this->exchangeOptions['x-delayed-message']) {
                $topic->setType('x-delayed-message');
                $topic->setArgument('x-delayed-type', $this->exchangeOptions['type']);
            } else {
                $topic->setType($this->exchangeOptions['type']);
            }

            if ($this->exchangeOptions['passive']) {
                $topic->addFlag(AmqpTopic::FLAG_PASSIVE);
            }
            if ($this->exchangeOptions['durable']) {
                $topic->addFlag(AmqpTopic::FLAG_DURABLE);
            }
            if ($this->exchangeOptions['auto_delete']) {
                $topic->addFlag(AmqpTopic::FLAG_AUTODELETE);
            }
            $this->topicMap[$exchangeName] = $topic;
            if ($this->exchangeOptions['declare'] && !in_array($exchangeName, $this->declaredExchanges, true)
                && empty($this->job->sendToTopic) //只有 consumer 声明topic
            ) {
                $this->context->declareTopic($topic);

                $this->declaredExchanges[] = $exchangeName;
            }
        } else {
            $topic = $this->topicMap[$exchangeName];
        }

        if (empty($this->queueMap[$queueName])) {
            $queue = $this->context->createQueue($queueName);
            $queue->setArguments($this->queueOptions['arguments']);
            if ($this->queueOptions['passive']) {
                $queue->addFlag(AmqpQueue::FLAG_PASSIVE);
            }
            if ($this->queueOptions['durable']) {
                $queue->addFlag(AmqpQueue::FLAG_DURABLE);
            }
            if ($this->queueOptions['exclusive']) {
                $queue->addFlag(AmqpQueue::FLAG_EXCLUSIVE);
            }
            if ($this->queueOptions['auto_delete']) {
                $queue->addFlag(AmqpQueue::FLAG_AUTODELETE);
            }
            if ($this->queueOptions['declare'] && !in_array($queueName, $this->declaredQueues, true)
                && empty($this->job->sendToTopic) //只有 consumer 声明队列
            ) {
                $this->context->declareQueue($queue);

                $this->declaredQueues[] = $queueName;
            }
            if ($this->queueOptions['bind']) {
                $this->context->bind(new AmqpBind($queue, $topic, $queue->getQueueName()));
            }
            $this->queueMap[$queueName] = $queue;
        } else {
            $queue = $this->queueMap[$queueName];
        }

        return [$queue, $topic];
    }

    /**
     * @param string $action
     * @param \Exception $e
     * @throws \Exception
     */
    protected function reportConnectionError($action, \Exception $e)
    {
        /** @var LoggerInterface $logger */
        $logger = $this->container['log'];

        $logger->error('AMQP error while attempting ' . $action . ': ' . $e->getMessage());

        // If it's set to false, throw an error rather than waiting
        if ($this->sleepOnError === false) {
            throw new RuntimeException('Error writing data to the connection with RabbitMQ', null, $e);
        }

        // Sleep so that we don't flood the log file
        sleep($this->sleepOnError);
    }

    public function getTopicMappingValue($queue, $key)
    {
        $queueTopicSubscribeMappings = config("queue.queueTopicSubscribeMapping.{$queue}");

        return $queueTopicSubscribeMappings[$key] ?? null;
    }

    protected function createPayload($job, $data = '')
    {
        $payload = json_encode($job->data);

        if (JSON_ERROR_NONE !== json_last_error()) {
            throw new InvalidPayloadException(
                'Unable to JSON encode payload. Error code: '.json_last_error()
            );
        }

        return $payload;
    }

    /**
     *  获取默认队列名（如果当前队列名为 null）。
     *
     * @param $queue
     *
     * @return string
     */
    public function getQueue($queue)
    {
        return config('queue.connections.rabbitmq.queue_name_prefix') . '-' . ( $queue ? $queue : $this->default);
    }
    public static function getAggQueueName()
    {
        $aggQueueName = config("queue.aggQueueName");

        return $aggQueueName ?? str_replace('api-', '', Config::get('app.api_operation_name_prefix'))  . 'normal-combine-queue-consumer';
    }
}
