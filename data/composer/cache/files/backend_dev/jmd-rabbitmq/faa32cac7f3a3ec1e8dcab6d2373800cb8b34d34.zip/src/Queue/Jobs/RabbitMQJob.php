<?php

namespace Jing\JmdRabbitMq\Queue\Jobs;

use Illuminate\Container\Container;
use Illuminate\Contracts\Queue\Job as JobContract;
use Illuminate\Database\DetectsDeadlocks;
use Illuminate\Queue\Jobs\Job;
use Illuminate\Queue\Jobs\JobName;
use Illuminate\Support\Str;
use Interop\Amqp\AmqpConsumer;
use Interop\Amqp\AmqpMessage;
use Jing\JmdRabbitMq\Queue\RabbitMQQueue;

class RabbitMQJob extends Job implements JobContract
{
    use DetectsDeadlocks;

    /**
     * Same as RabbitMQQueue, used for attempt counts.
     */
    const ATTEMPT_COUNT_HEADERS_KEY = 'attempts_count';

    protected $connection;
    protected $consumer;
    protected $message;

    protected $classMap;

    public function __construct(
        Container     $container,
        RabbitMQQueue $connection,
        AmqpConsumer  $consumer,
        AmqpMessage   $message
    )
    {
        $this->container = $container;
        $this->connection = $connection;
        $this->consumer = $consumer;
        $this->message = $message;
        $this->queue = $consumer->getQueue()->getQueueName();
        $this->classMap = config('queue.queueJobMappings');
    }

    /**
     * Fire the job.
     *
     * @return void
     * @throws Exception
     *
     */
    public function fire()
    {
        $start = microtime(true);
        echo "CURRENT TIME:" . date('Y-m-d H:i:s') . PHP_EOL;
        $memory1 = memory_get_usage(true);
        try {
            //防止队列消费失败反复重试阻塞队列
            $this->delete();
            $payload = $this->payload();

//            list($class, $method) = JobName::parse($payload['job']);
//
//            with($this->instance = $this->resolve($class))->{$method}($this, $payload['data']);
            $class = "Illuminate\\Queue\\CallQueuedHandler";
            $method = "call";
            ($this->instance = $this->resolve($class))->{$method}($this, $payload);
        } catch (\Exception $exception) {
            echo $exception->getMessage() . '|' . $exception->getTraceAsString().PHP_EOL;
        }
        $end = microtime(true);
        $memory2 = memory_get_usage(true);
        $usedMemory = self::memoryConvert($memory2 - $memory1);
        $currentMemory = self::memoryConvert($memory2 - 0);
        echo PHP_EOL . "FINISH TIME:" . ($end - $start) . ' Used Memory: ' . $usedMemory . ' Current Memory: ' . $currentMemory . PHP_EOL;
    }

    /**
     * Get the number of times the job has been attempted.
     *
     * @return int
     */
    public function attempts(): int
    {
        // set default job attempts to 1 so that jobs can run without retry
        $defaultAttempts = 1;

        return $this->message->getProperty(self::ATTEMPT_COUNT_HEADERS_KEY, $defaultAttempts);
    }

    /**
     * Get the raw body string for the job.
     *
     * @return string
     */
    public function getRawBody(): string
    {
        return $this->message->getBody();
    }

    /** @inheritdoc */
    public function delete()
    {
        parent::delete();

        $this->consumer->acknowledge($this->message);
    }

    /** @inheritdoc */
    public function release($delay = 0)
    {
        parent::release($delay);

        $this->delete();
        $this->connection->setAttempts($this->attempts() + 1);

        $body = $this->payload();

        /*
         * Some jobs don't have the command set, so fall back to just sending it the job name string
         */
        if (isset($body['data']['command']) === true) {
            $job = $this->unserialize($body);
        } else {
            $job = $this->getName();
        }

        $data = $body['data'];

        if ($delay > 0) {
            $this->connection->later($delay, $job, $data, $this->getQueue());
        } else {
            $this->connection->push($job, $data, $this->getQueue());
        }
    }

    /**
     * Get the job identifier.
     *
     * @return string
     */
    public function getJobId(): string
    {
        return $this->message->getCorrelationId();
    }

    /**
     * Sets the job identifier.
     *
     * @param string $id
     *
     * @return void
     */
    public function setJobId($id)
    {
        $this->connection->setCorrelationId($id);
    }

    /**
     * Unserialize job.
     *
     * @param array $body
     *
     * @return mixed
     * @throws Exception
     *
     */
    private function unserialize(array $body)
    {
        try {
            /** @noinspection UnserializeExploitsInspection */
            return unserialize($body['data']['command']);
        } catch (Exception $exception) {
            if (
                $this->causedByDeadlock($exception) ||
                Str::contains($exception->getMessage(), ['detected deadlock'])
            ) {
                sleep(2);

                return $this->unserialize($body);
            }

            throw $exception;
        }
    }

    public function payload()
    {
        $data = json_decode($this->getRawBody(), true);
        $jobClass = $this->getName();
        $job = new $jobClass($data);

        return array(
            "commandName" => $jobClass,
            "command" => serialize($job)
        );
    }

    public function getName()
    {
        $queueName = str_replace(config('queue.connections.rabbitmq.queue_name_prefix') . '-', '', $this->queue);
        if (isset($this->classMap[$queueName])) {
            $className = $this->classMap[$queueName];
        } else {
            throw new Exception(json_encode($this->classMap), 1);
//            throw new Exception("Invalid JOB QUEUE MAPPING : " . $queueName,1);
        }

        return $className;
    }


    public static function memoryConvert($size)
    {
        $unit = array('b', 'kb', 'mb', 'gb', 'tb', 'pb');
        return $size ? @round($size / pow(1024, ($i = floor(log($size, 1024)))), 2) . ' ' . ((isset($unit[$i])) ? $unit[$i] : '?') : 0;
    }
}
