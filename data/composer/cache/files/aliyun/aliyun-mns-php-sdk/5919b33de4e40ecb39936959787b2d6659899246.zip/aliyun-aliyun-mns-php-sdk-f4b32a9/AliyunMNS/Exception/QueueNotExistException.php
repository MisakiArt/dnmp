<?php
namespace AliyunMNS\Exception;

use AliyunMNS\Exception\MnsException;

class QueueNotExistException extends MnsException
{
}

?>
