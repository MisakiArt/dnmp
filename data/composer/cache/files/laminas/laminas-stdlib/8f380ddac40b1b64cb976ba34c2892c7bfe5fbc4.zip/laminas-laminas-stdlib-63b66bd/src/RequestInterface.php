<?php

declare(strict_types=1);

namespace Laminas\Stdlib;

interface RequestInterface extends MessageInterface
{
}
