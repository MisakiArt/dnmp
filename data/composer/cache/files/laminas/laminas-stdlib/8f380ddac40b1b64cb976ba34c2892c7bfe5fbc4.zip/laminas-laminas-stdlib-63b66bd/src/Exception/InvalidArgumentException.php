<?php

declare(strict_types=1);

namespace Laminas\Stdlib\Exception;

/**
 * Invalid Argument Exception
 */
class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
