<?php

declare(strict_types=1);

namespace longlang\phpkafka\Exception;

class CRC32Exception extends \Exception
{
}
