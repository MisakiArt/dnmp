<?php

declare(strict_types=1);

namespace longlang\phpkafka\Protocol;

abstract class AbstractResponse extends AbstractProtocol
{
}
