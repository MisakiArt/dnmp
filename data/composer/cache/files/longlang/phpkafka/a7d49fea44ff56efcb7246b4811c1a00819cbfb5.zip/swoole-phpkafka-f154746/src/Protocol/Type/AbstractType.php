<?php

declare(strict_types=1);

namespace longlang\phpkafka\Protocol\Type;

abstract class AbstractType
{
    private function __construct()
    {
    }
}
