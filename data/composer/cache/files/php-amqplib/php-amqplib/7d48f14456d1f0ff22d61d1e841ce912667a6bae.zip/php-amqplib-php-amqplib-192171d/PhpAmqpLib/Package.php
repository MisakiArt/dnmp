<?php

namespace PhpAmqpLib;

final class Package
{
    const NAME = 'AMQPLib';
    const VERSION = '3.2.0';
}
