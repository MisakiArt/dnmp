<?php

namespace PhpAmqpLib\Exception;

class AMQPHeartbeatMissedException extends AMQPConnectionClosedException
{
}
